
function myfunction(){
    var passenger=document.getElementById('passgno').value;
    var res=parseInt(passenger);
    
    for(var i=0;i<res;i++){
     document.getElementById('container').innerHTML+="<label>name</label><input type='text'placeholder='name'id='passengername'>"+
     "<br><br>"+
 "<br><br>"+"<label>Age</label><input type='text'id='passengerage' placeholder='age'>"+
 "<br><br>"
 +"<br><br><label>Gender</label><input type='radio' name='gender'id='male' value='male'>male"+
 "<input type='radio' name= 'gender' id='female'value='female'> female<br><hr><br>"
    }
}

function myfun(){
    var i=0;
    var passgno=document.getElementById("passgno").value;
    do{
    var passengername=document.getElementById('passengername').value;
    var passengerage=document.getElementById('passengerage').value;

    var passengergender;
    if (document.getElementById('male').checked) {
        passengergender= document.getElementById('male').value;
    }
    else{
        passengergender=document.getElementById('female').value;
    }
    var data={
        "passengername":passengername,
        "passengerage":passengerage,
        "passengergender":passengergender
    }
    let options = {
        method:'POST',
        headers:{
            'Content-Type':'application/json'
        },
        body:JSON.stringify(data)
    }
   
    let fres = fetch("http://localhost:8080/api/passengers",options);
    fres.then(res => res.json()).then(d => {
        console.log("success"+ d);
       
    })
    i++;
}
while(i<passgno)
    alert("sucess");

}
        
    
