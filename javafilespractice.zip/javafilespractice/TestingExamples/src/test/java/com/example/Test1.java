package com.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test1 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\user75\\Documents\\libs\\chromedriver_win32\\chromedriver.exe");
		WebDriver test = new ChromeDriver();
		test.get("https://www.facebook.com/");
		test.findElement(By.xpath("//input[@id='email']")).sendKeys("ai@gmail.com");
		test.findElement(By.xpath("//input[@id='pass']")).sendKeys("123456789");
		test.findElement(By.name("login")).click();
		

}
}
