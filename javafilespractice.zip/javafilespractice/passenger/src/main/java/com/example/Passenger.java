package com.example;

public class Passenger {
	private String passname;
	private int passage;
	private String passgender;
	public Passenger() {
		System.out.println("default constructor...");
	}
	public Passenger(String passname,int passage,String passgender) {
		this.passname=passname;
		this.passage=passage;
		this.passgender=passgender;
		
	}
	public void display() {
		System.out.println(passname+" "+passage+" "+passgender);
	}

}
