package com.example;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class TestPassenger {

	public static void main(String[] args) {
		Resource rs = new ClassPathResource("application.xml");
		BeanFactory factory=new XmlBeanFactory(rs);
		Passenger passenger=(Passenger) factory.getBean("passBean");
		Passenger passengers=(Passenger) factory.getBean("passBeans");
		passenger.display();
		passengers.display();
		
	}

}
