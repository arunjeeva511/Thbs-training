package SessionOnExceptions;

public class Nullpointexcep {

	public static void main(String[] args) {
		String name=null;
		//System.out.println(name.length());
		try {
			System.out.println(name.length());
		}
		catch(NullPointerException e) {
			//ex.printStackTrace();
			System.out.println(e.getMessage());
			//System.out.println(e.toString());
		}
	
	}

}
