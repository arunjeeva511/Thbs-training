package SessionOnExceptions;

public class AirthmeticExcep {

	public static void main(String[] args) {
		int num=40;
		try {
			System.out.println(40/0);
		}
		catch(ArithmeticException ex) {
			
			System.out.println(ex);
			
			
		}
	}

}
