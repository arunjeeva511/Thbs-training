package SessionOnExceptions;
import java.io.IOException;
import java.util.*;
	class A11{
		void display()throws IOException{
			System.out.println("msg from display");
			throw new IOException("input output error");
		}
	}
public class ThrowsTest1 {

	public static void main(String[] args) throws IOException {
		A11 obj=new A11();
		obj.display();
	}

}
