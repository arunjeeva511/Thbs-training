package SessionOnExceptions;

public class NestedTryExcep {

	public static void main(String[] args) {
		
		try {
			System.out.println(1);
			String name="pragathi";
			try {
				System.out.println(2);
				System.out.println(name.charAt(9));
				
			}
			catch(StringIndexOutOfBoundsException ex) {
				
				System.out.println(ex);
			}
			System.out.println(4);
		}
		catch(Exception e) {
			System.out.println("exception");
		}
	}

}
