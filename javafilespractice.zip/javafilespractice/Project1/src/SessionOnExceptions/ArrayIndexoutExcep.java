package SessionOnExceptions;

public class ArrayIndexoutExcep {

	public static void main(String[] args) {
		int[] arr= {12,3,4,23,24};
		try {
			System.out.println(arr[7]);
		}
		catch(ArrayIndexOutOfBoundsException ex) {
			System.out.println("exception occured by AIOBE block:"+ex);
			
		
		}

	}

}
