package SessionOnExceptions;
class A{
	int num;
	A(int num){
		this.num=num;
		
	}
	void display() {
		System.out.println("number is:"+num);
	}
}
class B extends A{
	B(int num){
		super(num);
	}
	void display() {
		System.out.println("number is:"+num+"from class B");
	}
}
public class ClassCastExcep {

	public static void main(String[] args) {
		B b1= new B(20);
		A a1=new A(30);
		//a1=b1;
		//a1.display();
		//A obj3=new A(40);
		//B obj=(B)obj3;
		//A obj=(A)b1;  ---->b1 class cast to A
		//obj.display();
		try {
			B obj=(B)a1;  
			obj.display();
			}
		catch(Exception e) {
			System.out.println(e);
		}
		finally {
			System.out.println("ok bye");
		}
	}

}
