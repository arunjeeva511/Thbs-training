package SessionOnExceptions;
class InvalidUser extends Exception{
	public InvalidUser(String msg) {
		super(msg);
	}
}
public class CustomExcep {
	static void ValidateUser(String username,String password)throws InvalidUser{
		if(username.equals("admin")&& password.equals("admin123")) {
			System.out.println("user is valid");
		}
		else {
			throw new InvalidUser("invalid user");
		}
	}

	public static void main(String[] args)  {
		try {
			ValidateUser("admin","admin123");
		} catch (InvalidUser e) {
			
			e.printStackTrace();
		}
	}

}
