package SessionOnExceptions;

public class ThrowsExcep {
	static void task() throws NullPointerException{
		System.out.println("with in task.....");
	throw new NullPointerException("no value present");
	}
	public static void main(String[] args) {
		try {
			task();
		}
		catch(NullPointerException e) {
			System.out.println("caught in main" +" "+e.getMessage());
		}
	}

}
