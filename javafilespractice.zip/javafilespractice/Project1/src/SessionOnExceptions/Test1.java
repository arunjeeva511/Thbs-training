package SessionOnExceptions;

public class Test1 {

	public static void main(String[] args) {
		int num=20;
		String msg=null;
		try {
			System.out.println(msg.length());
			System.out.println(num/0);
			
		}
		catch(NullPointerException ex) {
			System.out.println(ex);
			System.out.println("hello");
			
		}
		catch(ArithmeticException ex) {
			System.out.println(num/(0+1));
			System.out.println("hello");
		}
	}

}
