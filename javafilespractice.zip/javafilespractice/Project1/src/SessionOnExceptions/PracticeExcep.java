package SessionOnExceptions;
import java.util.*;
public class PracticeExcep {
	static boolean checkingUsername(String username) throws Exception {
		if(username.length()==0)	{
			throw new Exception("please enter the username");
		}
		else {
			return true;
		}
	}
	public static void main(String[] args) {
		PracticeExcep practice=new PracticeExcep();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the username");
		String username=sc.nextLine();
		try {
			if(checkingUsername(username)) {
				System.out.println(username.length());
				System.out.println("enter the password");
			}}
			catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
		
	}


