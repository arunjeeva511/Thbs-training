package SessionOnExceptions;

public class ThrowExcep {
	static boolean checkNumber(int num) {
		if (num==0) {
			throw new  ArithmeticException("divide by zero error by");
		}
		else {
			return true;
		}
	}

	public static void main(String[] args) {
		ThrowExcep t=new ThrowExcep();
		int num1=30;
		int num2=1;
		
		System.out.println(1);
		try {if(checkNumber(num2)) {
			int result =num1/num2;
			System.out.println("result:"+result);
		}}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		System.out.println(2);	
		
	}

}
