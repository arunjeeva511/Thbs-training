package SessionOnExceptions;

public class Test2 {

	public static void main(String[] args) {
		int num=20;
		String name=null;
		try {
			System.out.println(num/0);
			System.out.println(name.length());
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
	}

}
