package SessiononjavaInPutOutPut;

import java.io.FileInputStream;
import java.io.InputStream;

public class FileInputStreamExample {

	public static void main(String[] args) {
		InputStream ip=null;
		try {
		ip=new FileInputStream("C:\\Users\\user75\\eclipse-workspace\\Project1\\src\\SessiononjavaInPutOutPut\\arun.txt");
		int i;
		while((i=ip.read())!=-1) {
		System.out.print((char)i);
		}
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}

}
