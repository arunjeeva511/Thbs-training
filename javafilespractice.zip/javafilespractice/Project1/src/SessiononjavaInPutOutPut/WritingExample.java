package SessiononjavaInPutOutPut;

import java.io.FileWriter;
import java.io.IOException;

public class WritingExample {

	public static void main(String[] args) {
		String msg="hello everyone my name is Arun";
		try {
			FileWriter fw=new FileWriter("C:\\\\Users\\\\user75\\\\eclipse-workspace\\\\Project1\\\\src\\\\SessiononjavaInPutOutPut\\\\arun.txt");
			fw.write(msg);
			fw.close();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		System.out.println("done....");
	}

}
