package SessiononjavaInPutOutPut;

import java.io.FileWriter;

import org.json.simple.JSONObject;

public class JsonExample {

	public static void main(String[] args) {
		String msg="hello everyone my name is Arun";
		try {
			FileWriter fw=new FileWriter("C:\\\\Users\\\\user75\\\\eclipse-workspace\\\\Project1\\\\src\\\\SessiononjavaInPutOutPut\\\\arun.txt");
			JSONObject obj=new JSONObject();
			obj.put("i",1);
			obj.put("name","john");
			obj.put("age", 23);
			fw.write(obj.toJSONString());
			fw.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("done.......");
	}

}
