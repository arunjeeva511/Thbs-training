package SessiononjavaInPutOutPut;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class UsingFileReader {

	public static void main(String[] args) {
		File f=new File("C:\\Users\\user75\\eclipse-workspace\\Project1\\src\\SessiononjavaInPutOutPut\\arun.txt");
		try {
			FileReader r=new FileReader(f);
			int i;
			while((i=r.read())!=-1) {
				System.out.print((char)i);
			}
		}
			catch(Exception e) {
				System.out.println(e);
			}
			
		}
		
	}


