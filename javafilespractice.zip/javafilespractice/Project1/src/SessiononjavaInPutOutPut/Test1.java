package SessiononjavaInPutOutPut;

import java.io.IOException;
import java.io.InputStreamReader;

public class Test1 {

	public static void main(String[] args) throws IOException {
		System.out.println("enter characters,"+"'0' to quit");
		char c;
		do {
			InputStreamReader ip=new InputStreamReader(System.in);
			c=(char)ip.read();
			System.out.println("the entered character is "+" "+c);
		}
		while (c!='0');
	}
		
	}


