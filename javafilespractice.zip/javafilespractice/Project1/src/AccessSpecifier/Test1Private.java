package AccessSpecifier;

public class Test1Private {

	public static void main(String[] args) {
		System.out.println( Test1.number);
	}

}
