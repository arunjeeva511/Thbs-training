package AccessSpecifier;
import JavaSamples.*;
public class ForProtected extends ForCheckingAccessSpecifer {

	public static void main(String[] args) {
		ForProtected forp=new ForProtected();
		
		forp.msg();
		System.out.println(forp.city);
		
		
	}

}
