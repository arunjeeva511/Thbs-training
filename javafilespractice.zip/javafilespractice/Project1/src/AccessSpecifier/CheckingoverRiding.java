package AccessSpecifier;
class A{
	 void show() {
		System.out.println("hello");
	}
}

public class CheckingoverRiding extends A {
	 void show() {
		System.out.println("hello from checking");
	}

	public static void main(String[] args) {
		CheckingoverRiding c=new CheckingoverRiding();
		c.show();
	}

}
