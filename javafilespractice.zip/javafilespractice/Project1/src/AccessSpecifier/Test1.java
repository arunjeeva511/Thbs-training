package AccessSpecifier;

public class Test1 {
	static int number=100;

	public static void main(String[] args) {
		//Test1 test=new Test1();
		System.out.println(number);
	}

}
