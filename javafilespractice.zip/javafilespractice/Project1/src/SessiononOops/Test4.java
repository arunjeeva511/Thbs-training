package SessiononOops;
class Player{
	String name;
	String role;
	int runs;
	int wickets;
	String franchiese;
	Player(){
		System.out.println("Default constructors");
	}
	Player(String name,String role,int runs,int wickets,String franchiese){
		this.name=name;
		this.role=role;
		this.runs=runs;
		this.wickets=wickets;
		this.franchiese=franchiese;
	}
	void display() {
		System.out.println(name+ " "+ " "+role+" "+runs+" "+wickets+" "+franchiese);
	}
}
public class Test4 {

	public static void main(String[] args) {
		Player p=new Player("Abdevelliers","Batsman",24500,23,"RCB");
		Player p1=new Player("Virat","Batsman",34520,34,"RCB");
		Player p2=new Player("Hardikpandya","Allrounder",4539,45,"MumbaiIndians");
		p.display();
		p1.display();
		p2.display();

	}

}
