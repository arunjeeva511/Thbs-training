package SessiononOops;
class Car{
	String brand="suv";
	String model="mahindra";
	String color="black";
	double price=7657585.09d;
}

public class Test1 {

	public static void main(String[] args) {
		Car car=new Car();
		System.out.println(car.brand);
		System.out.println(car.model);
		System.out.println(car.color);
		System.out.println(car.price);
		
		

	}

}
