package SessiononOops;
class Bike{
	String name;
	String color;
	String speed;

Bike(String name,String color,String speed){
	this.name=name;
	this.color=color;
	this.speed=speed;
}
void display()
{
	System.out.println(name+" "+color+" "+speed);
}
}
public class Test3 {

	public static void main(String[] args) {
		Bike bike=new Bike("KTM","white","120kmph");
		bike.display();

	}

}
