package SessiononOops;
class Cricket{
	String name;
	String role;
	int runs;
	int wickets;
	String franchise;
	void display() {
		System.out.println("information of crickter:"+name+" "+role+" "+runs+" "+wickets+" "+franchise);
	}
}

public class ExampleOfObjects {

	public static void main(String[] args) {
		Cricket cricket=new Cricket();
		cricket.name="Abd";
		cricket.role="Batsman";
		cricket.runs=24500;
		cricket.wickets=40;
		cricket.franchise="RCB";
		Cricket cricket1=new Cricket();
		cricket1.name="viratKholi";
		cricket1.role="Batsman";
		cricket1.runs=34500;
		cricket1.wickets=50;
		cricket1.franchise="RCB";
		Cricket cricket2=new Cricket();
		cricket2.name="Hardikpandya";
		cricket2.role="Allrounder";
		cricket2.runs=4500;
		cricket2.wickets=50;
		cricket2.franchise="MumbaiIndians";
		
		cricket.display();
		cricket1.display();
		cricket2.display();

	}

}
