package SessiononOops;
class Books {
	int book_id;
	String Name;
	Books(){
		//book_id=101;
		//Name="sachin";
		System.out.println("default Constructor");
	}
	void dispaly() {
		System.out.println(+ book_id+" "+Name );
	}
}
public class ConstructorExample {

	public static void main(String[] args) {
		Books book=new Books();
		//book.dispaly();
		

	}

}
