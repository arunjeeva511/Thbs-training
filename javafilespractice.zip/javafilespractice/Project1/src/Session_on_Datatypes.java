
public class Session_on_Datatypes {

	public static void main(String[] args) {
		int num=10;
		double salary=100023.0045;
		char ch='A';
		boolean flag=true;
		System.out.println(num);
		System.out.println(salary);
		System.out.println(ch);
		System.out.println(flag);

	}

}
