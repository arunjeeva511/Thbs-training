package SessiononAbstract;
abstract class A{
	void display() {
		System.out.println("hello hi");
	}
	abstract void show();
}

public class FirstClass extends A {
	void show() {
		System.out.println("hi hello");
	}

	public static void main(String[] args) {
		//FirstClass firstclass=new FirstClass();
		A firstclass=new FirstClass();
		firstclass.display();
		firstclass.show();
	}

}
