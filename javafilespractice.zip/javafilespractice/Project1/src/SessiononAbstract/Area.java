package SessiononAbstract;
abstract class Shapes{
	int l;
	int b;
	Shapes(int l,int b){
		this.l=l;
		this.b=b;
		}
	abstract void area();
}
class Rectangle1 extends Shapes{
	Rectangle1(int l,int b){
		super(l,b);
		}
	void area() {
		float res;
		res=l*b;
		System.out.println("the area of rectangle is:"+res);
		
	}
}
class Traingle extends Shapes{
	Traingle(int l,int b){
		super(l,b);
		}
	void area() {
		double res;
		res=(l*b)*(0.5);
		System.out.println("the area of traingle is:"+res);
		
	}
}


public class Area {

	public static void main(String[] args) {
		Traingle obj=new Traingle(20,40);
		obj.area();
		Rectangle1 obj1=new Rectangle1(20,40);
	obj1.area();
	}
	

}
