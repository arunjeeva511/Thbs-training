package SessiononAbstract;
abstract class Bank{
	int amount=25000;
	int time=2;
	abstract int calculateinterest();
	
}
class Sbi extends Bank{
	int rate=8;
	int calculateinterest() {
		int result=(amount*time*rate)/100;
		return result;
	}
}
class KarnatakaBank extends Bank {
	int rate=7;
	int calculateinterest() {
		int result=(amount*time*rate)/100;
		return result;
	}
}


public class BankUsing {

	public static void main(String[] args) {
		Bank b;
		b=new Sbi();
		Bank b1=new KarnatakaBank();
		int result1=b.calculateinterest();
		int result2=b1.calculateinterest();
		System.out.println("the amount of money in Sbi bank is:"+result1);
		System.out.println("the amount of money in karnataka bank is:"+result2);
		
	}

}
