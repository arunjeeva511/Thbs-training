package SessiononAbstract;
class Bikes{
	int speed=200;
	Bikes(){
		System.out.println("bike running at speed of"+speed+"km/hr");
	}
	void display() {
		System.out.println("msg from display");
	}
}
class Honda extends Bikes{
	int speed=100;
	Honda(){
		super();
		System.out.println("Honda Bike is good.....");
	}
	void show() {
		System.out.println(super.speed);
		System.out.println(speed);
		display();
	}
}

public class ExampleOnSuper {

	public static void main(String[] args) {
		Honda obj=new Honda();
		obj.show();
		
	}

}
