package SessiononEncapuslation;

public class ForSimple {

	public static void main(String[] args) {
		Simple simple=new Simple();
		simple.setUsername("Arun");
		simple.setEmail("arunarukumar@gmail.com");
		System.out.println(simple.getUsername());
		System.out.println(simple.getEmail());
		
		 Productencap productencap=new  Productencap();
		 productencap.setProductid(2);
		 productencap.setProductname("laptop");
		 productencap.setProductprice("345089");
		 Productencap productencap1=new  Productencap();
		 productencap1.setProductid(4);
		 productencap1.setProductname("tv");
		 productencap1.setProductprice("456789");
		 System.out.println(productencap.getProduct_id()+" "+productencap.getProduct_name()+" "+productencap.getProduct_price());
		 System.out.println(productencap1.getProduct_id()+" "+productencap1.getProduct_name()+" "+productencap1.getProduct_price());
	}

}
