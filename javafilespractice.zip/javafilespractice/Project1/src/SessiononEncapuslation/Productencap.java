package SessiononEncapuslation;

public class Productencap {
	int product_id;
	String product_price;
	String product_name;
	public void setProductid(int product_id) {
		this.product_id=product_id;
	}
	public int getProduct_id() {
		return product_id;
	}
	public void setProductprice(String product_price) {
		this.product_price=product_price;
	}
	public String getProduct_price() {
		return product_price;
	}
	public void setProductname(String product_name) {
		this.product_name=product_name;
	}
	public String getProduct_name() {
		return product_name;
	}
	

}
