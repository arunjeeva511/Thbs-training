package SessionOnInterface;
interface I1{
	void dispaly();
	void calculate();
}
public class Test1 implements I1 {
	

	
	@Override
	public void dispaly() {
		System.out.println("message from display");
	}

	@Override
	public void calculate() {
		System.out.println("message from calculate");
	}
public static void main(String[] args) {
		Test1 test1=new Test1();
		test1.calculate();
		test1.dispaly();
	}


}
