package SessionOnInterface;
interface Draw{
	void draw();
	static int cube(int x) {
		return x*x*x;
	}
}
class Rectangle implements Draw{
	public void draw() {
		System.out.println("drawing rectangle");
	
		
	}
}

public class StaticUsing {

	public static void main(String[] args) {
		Rectangle rectangle=new Rectangle();
		rectangle.draw();
		System.out.println(Draw.cube(5));
		
	}

}
