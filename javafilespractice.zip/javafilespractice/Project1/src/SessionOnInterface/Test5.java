package SessionOnInterface;
interface Add{
	void addition(int x,int y);
}
public class Test5 {

	public static void main(String[] args) {
		Add obj=new Add() {
			public void addition(int x,int y) {
				int res;
				res=x+y;
				System.out.println("sum of two numbers are:"+res);
			}
		};
		obj.addition(40, 50);
		
	}

}

