package SessionOnInterface;
interface Printable{
	 void print();
}
interface Showable{
	void show();
}
public class ExampleMultiinheritance implements Printable,Showable {
	public   void print() {
		System.out.println("hello");
	}
	public void show() {
		System.out.println("welcome");
		
	}

	public static void main(String[] args) {
		ExampleMultiinheritance obj=new ExampleMultiinheritance();
		obj.print();
		obj.show();

	}

}
