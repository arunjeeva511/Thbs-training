package SessiononGenerics;
import java.util.*;
public class Test4 {

	public static void main(String[] args) {
		ArrayList<String>al=new ArrayList<String>();
		al.add("arun");
		al.add("pragathi");
		al.add("ravi");
				System.out.println(al.get(0));
		
	}

}
