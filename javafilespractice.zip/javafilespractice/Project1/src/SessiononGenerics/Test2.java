package SessiononGenerics;
class A1<T,U>{
	T name;
	U marks;
	A1(T name,U marks){
		this.marks=marks;
		this.name=name;
		
	}
	void show() {
		System.out.println(name+" "+marks);
	}
}

public class Test2 {

	public static void main(String[] args) {
		A1<String,Integer> obj=new A1<String,Integer>("Arun",49);
		obj.show();
		
	}

}
