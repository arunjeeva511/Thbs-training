package SessiononGenerics;

public class Test3 {
	static <T> void display(T item) {
		System.out.println(item.getClass().getName()+" "+item);
	}

	public static void main(String[] args) {
		display(200);
		
		
	}

}
