package SessiononGenerics;
class A<T>{
	T value;
	A(T value){
		this.value=value;
	}
	T getObject() {
		return value;
	}
}

public class Test1 {

	public static void main(String[] args) {
		A<Integer>obj=new A<Integer>(30);
		System.out.println(obj.getObject());
		A<String> str=new A<String>("Arun");
		System.out.println(str.getObject());
		A<Character>ch=new A<Character>('a');
		System.out.println(ch.getObject());
		
		
		
	}

}
