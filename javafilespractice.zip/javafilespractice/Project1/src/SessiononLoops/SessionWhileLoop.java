package SessiononLoops;

public class SessionWhileLoop {

	public static void main(String[] args) {
		int i=5;
		while(i>0) {
			System.out.println(i);
			i--;
		}

	}

}
