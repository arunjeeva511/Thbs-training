
public class Session_of_Arrays {

	public static void main(String[] args) {
		//int arr1[]= {20,40,50,60,70};
		//System.out.println(arr1[4]);
		String name="Arun";
		System.out.println("my name is "+name);

	}

}
