package SessionOnInheritance;
class A{
	int number=10;
}
class B extends A{
	void display() {
		System.out.println(number);
	}
}
public class FirstExample {

	public static void main(String[] args) {
		B b=new B();
		b.display();
		
	}

}
