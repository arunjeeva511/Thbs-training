package SessionOnInheritance;
class A11{
	int num1=10;
}
class B11 extends A11{
	int num2=20;
}
class C11 extends B11{
	int num3=40;
	void result() {
		int res=num1+num2+num3;
		System.out.println(res);
	}
}
class D11 extends C11{
	void result() {
		int result=num1+num2;
		System.out.println(result);
	}
	
}
public class ExampleForMulti {

	public static void main(String[] args) {
		D11 cobj=new D11();
		cobj.result();

	}

}
