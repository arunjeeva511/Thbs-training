package SessionOnInheritance;
class A0{
	int num1=20;
}
class B0 extends A0{
	int num2=30;
	int res;
	void cal() {
		res=num1+num2;
		System.out.println(res);
	}
}
class C0 extends A0{
	int num2=2;
	void cal() {
		int re=num1/num2;
		System.out.println(re);
	}
}
class D0 extends C0{
	void display() {
	System.out.println("hello....");
	cal();
	}
}
public class ExampleOfHybridInhirit {

	public static void  main(String[] args) {
		D0 obj=new D0();
		obj.display();

	}

}
