package SessionOnInheritance;
class Add{
	int number1=30;
	int number2=5;
}
class Operations extends Add{
	void dispaly() {
		int sum=number1+number2;
		int sub=number1-number2;
		int mul=number1*number2;
		int div=number1/number2;
		System.out.println(sum+" "+sub+" "+mul+" "+div);
	}
}

public class AdditionUsingInheritance {

	public static void main(String[] args) {
		Operations obj=new Operations();
		obj.dispaly();

	}

}
