package SessionOnInheritance;
	class Bank{
		String name="kbl";
		String ifsccode="karboo1";
		
	}
	class Customer extends Bank{
		String cname="virat";
		int accno=356363;
	}
public class IsAAndHasARealtion {

	public static void main(String[] args) {
		Customer custm=new Customer();
		System.out.println("bank name:"+custm.name);
		System.out.println("bank ifscode:"+custm.ifsccode);
		System.out.println(custm.cname);
		System.out.println(custm.accno);

	}

}
