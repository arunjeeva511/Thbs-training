package JavaSamples;

public class SeesiononOperators {

	public static void main(String[] args) {
		int num1=40;
		int num2=4;
		System.out.println(num1+num2);
		System.out.println(num1-num2);
		System.out.println(num1*num2);
		System.out.println(num1/num2);
	}

}
