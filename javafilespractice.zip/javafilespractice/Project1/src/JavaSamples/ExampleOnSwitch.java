package JavaSamples;

import java.util.Scanner;
class Democracy{
	Scanner x=new Scanner(System.in);
	public String upper(String str1) {
		System.out.println("enter the string");
		str1=x.next();
		return str1.toUpperCase();
	}
	public String lower(String str1) {
		System.out.println("enter the string");
		str1=x.next();
		return str1.toLowerCase();
	}
	public boolean Compare(String str1,String str2) {
		System.out.println("enter the string");
		str1=x.next();
		System.out.println("enter the string");
		str2=x.next();
		
		return str1.contains(str2);
	
}
}

public  class ExampleOnSwitch  {

	public static void main(String[] args) {
		String str1="arun";
		Scanner sc=new Scanner(System.in);
		System.out.println("the string method are:");
		System.out.println("1 upper\n 2 lowe\n 3 compare\n 4 exit");
		System.out.println("enter your choice");
		int choice =sc.nextInt();
		Democracy demo=new Democracy();
		while(choice!=4){
			switch(choice) {
			case 1:String result=demo.upper(str1);
			System.out.println(result);
			break;
			case 2:String result1=demo.lower(str1);
			System.out.println(result1);
			break;
			case 3:boolean result3=demo.Compare(str1, str1);
			break;
			case 4:System.exit(0);
			break;
			default:System.out.println("invalid");
			
			}
		}
		
		

	}

}
