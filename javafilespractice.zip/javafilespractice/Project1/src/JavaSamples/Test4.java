package JavaSamples;

import java.util.Scanner;

public class Test4 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the percentage");
		int percentage=sc.nextInt();
		if(percentage>=85 && percentage<=100) {
			System.out.println("fcd");
		}
		else if(percentage>=60 && percentage<85 ) {
			System.out.println("first class");
		}else if(percentage>=35 && percentage<60) {
System.out.println("pass");

	}else if(percentage>=0 && percentage<35) {
		System.out.println("fail");
	}
	else {
		System.out.println("enter percentage between 0 to 100");
	}
		sc.close();

}
}
