package JavaSamples;

public class SessionOnIncrement {
	public static void main(String [] args) {
 int num1=40;
 int num2=50;
 int num3=++num1 + num2++;
 ++num1;
 --num2;
 num1=num1++ + --num3;
 System.out.println(num1);
 System.out.println(num2);
 System.out.println(num3);
}
}
