package JavaSamples;

public class SessiononTernary {

	public static void main(String[] args) {
		int num1=50;
		int num2=90;
		int res;
		res=(num1!=num2)?num1:num2;
		System.out.println(res);

	}

}
