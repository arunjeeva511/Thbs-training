package JavaSamples;


public class ForCheckingAccessSpecifer {
	//private int  num = 100;
	protected String city="Tumakuru";
     protected void msg() {
		System.out.println("hello");}
	int num=100;
	

	public static void main(String[] args) {
		ForCheckingAccessSpecifer forCheckingAccessSpecifer=new ForCheckingAccessSpecifer();
		
//System.out.println(forCheckingAccessSpecifer.num);
	}

}
