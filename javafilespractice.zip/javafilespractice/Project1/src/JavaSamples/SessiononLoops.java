package JavaSamples;

import java.util.Scanner;

public class SessiononLoops {
public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the age");
		int age=sc.nextInt();
		if(age>18)
		{
			System.out.println("eligible to vote");
		}
		else {
			System.out.println("not eligible");
		}
		sc.close();
		

	}

}
