package SessiononPolymorphism;
class MethodOverride{
	void display() {
		System.out.println("hello from Methodoverride");
	}
}
class Abc extends MethodOverride{
	void display() {
		System.out.println("hello from Abc");
	}
}

public class Test2 {

	public static void main(String[] args) {
		Abc abc=new Abc();
		abc.display();
	}

}
