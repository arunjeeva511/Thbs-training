package SessiononPolymorphism;
class Poly{
	int add(int a,int b) {
		return a+b;
	}
	int add(int a,int b,int c) {
		return a+b+c;
	}
}
public class SimpleExample {

	public static void main(String[] args) {
		Poly poly=new Poly();
		int result=poly.add(20, 30);
		int result1=poly.add(30, 40, 50);
		System.out.println(result+" "+result1);
		

	}

}
