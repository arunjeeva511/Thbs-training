package SessiononPolymorphism;
class Sum{
	static double add(double x,double y) {
		return x+y;
	}
	static int add(int x,double y) {
		return (int) (x+y);
		
	}
}
public class Test1 {

	public static void main(String[] args) {
		int result=Sum.add(24,56.56);
		double result1=Sum.add(45.6, 78.90);
		System.out.println(result+" "+result1);
	
	}

}
