package SessiononPolymorphism;
class Vehicle{
	void display(){
		System.out.println("vehicle");
	}
}
class Bike extends Vehicle{
	void dispaly() {
		System.out.println("bike");
	}
}
public class Test3 {

	public static void main(String[] args) {
	Bike bike=new Bike();
	bike.dispaly();
	}

}
