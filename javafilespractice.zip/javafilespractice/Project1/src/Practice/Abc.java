package Practice;

public class Abc {

	public static void main(String[] args) {
	}
}
