package Practice;
class Player{
	String name="Sachin";
	int age=48;
	}
class Player1 extends Player{
	int runs=50000;
	String role="Batter";
	void display() {
		System.out.println("name:"+" "+name+" "+"age:"+""+age+" "+"runs scored:"+" "+runs+" "+"role:"+" "+role);
	}
}

public class ExampleOfInheritance {

	public static void main(String[] args) {
		Player1 player=new Player1();
		player.display();

	}

}
