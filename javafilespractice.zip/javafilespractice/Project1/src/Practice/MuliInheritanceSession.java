package Practice;
class Player0{
	String name="VenkateshIyer";
	int age=21;
}
class Player11 extends Player0{
	int runs=2050;
}
class Player2 extends Player11{
	int wickets=20;
	void display() {
		System.out.println(name+" "+age+" "+runs+" "+wickets);
	}
}
public class MuliInheritanceSession {

	public static void main(String[] args) {
		Player2 player=new Player2();
		player.display();
		
	}

}
