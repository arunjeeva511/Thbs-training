package SessionOnWrapper;

public class UnboxingExample {

	public static void main(String[] args) {
		Integer num=50;
		int num1=num;
		System.out.println(num1);
		

	}

}
