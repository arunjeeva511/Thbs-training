package SessionOnWrapper;

public class BoxingExample {

	public static void main(String[] args) {
		int a=30;
		Integer num2=Integer.valueOf(a);
		Integer num1=a;
		Integer num=new Integer(a);
		System.out.println(num);
		System.out.println(num1);
		System.out.println(num2);
		
	}

}
