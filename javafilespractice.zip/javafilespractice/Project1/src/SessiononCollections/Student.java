package SessiononCollections;

import java.util.ArrayList;
import java.util.Scanner;

public class Student {
	private String name;
	private int age;
	
public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}
	static ArrayList<Student>stu=new ArrayList<Student>();
	static Scanner scan=new Scanner(System.in);
	public static void main(String[] args) {
		Student student=new Student();
		student.setName("arun");
		student.setAge(18);
		Student student1=new Student();
		student1.setAge(21);
		student1.setName("virat");
		stu.add(student1);
		stu.add(student);
		System.out.println(stu);
		
	}


	@Override
	public String toString() {
		return "Student [name=" + name + ", age=" + age + "]";
	}
	

}
