package SessiononCollections;
import java.util.*;
public class ArrayListUsingString {

	public static void main(String[] args) {
		ArrayList<String>str=new ArrayList<String>();
		str.add("Arun");
		str.add("ravi");
		str.add(null);
		str.add("kushal");
		str.add("jannardhan");
		str.add("sadqiq");
		//for(int i=0;i<str.size();i++) {
			//System.out.println(str.get(i));
	
	//	}
		//Iterator it=str.iterator();
		//while(it.hasNext()) {
			//System.out.println(it.next());
	//	}
		System.out.println(str);
		
	
	}

}
