package SessiononCollections;

import java.util.Stack;

public class StackExample {

	public static void main(String[] args) {
		Stack<String> str=new Stack<String>();
		str.push("Arun");
		str.add("hello");
		str.push("virat");
		str.add("sachin");
		System.out.println(str);
		System.out.println("-----------------------------------------");
		str.pop();
		System.out.println(str);

	}

}
