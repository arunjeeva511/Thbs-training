package SessiononCollections;

import java.util.HashSet;
import java.util.Set;

public class SetsExample {

	public static void main(String[] args) {
		Set<String>set=new HashSet<String>();
		set.add("arun");
		set.add("john");
		set.add("rahul");
		set.add("sachin");
		set.add("john");
		System.out.println(set);
		
	}

}
