package SessiononCollections;

import java.util.HashMap;

public class HashMapKeyValueExample {

	public static void main(String[] args) {
		HashMap<Integer,String>map=new HashMap<Integer,String>();
		map.put(1, "Abhi");
		map.put(2, "jeeva");
		map.put(3, "pragathi");
		map.put(4, "virat");
		map.put(null, "abd");
		System.out.println(map);
		System.out.println(map.remove(null));
		System.out.println(map);
		
	}

}
