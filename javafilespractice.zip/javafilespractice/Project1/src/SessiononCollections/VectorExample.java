package SessiononCollections;

import java.util.Vector;

import java.util.*;

public class VectorExample {

	public static void main(String[] args) {
		Vector<String>obj=new Vector<String>();
		obj.add("arun");
		obj.add("virat");
		obj.add("sachin");
	
	Iterator it =obj.iterator();
	while(it.hasNext()) {
		System.out.println(it.next());
	}
	}

}
