package SessiononCollections;

import java.util.Deque;
import java.util.LinkedList;

public class DequeExample {

	public static void main(String[] args) {
		Deque<String>deque=new LinkedList<String>();
		deque.add("item1");
		deque.add("item2");
		deque.add("item3");
		deque.addFirst("arun");
		deque.addLast("kumar");
		System.out.println(deque);
		deque.pop();
		System.out.println(deque);
		
	System.out.println("---------------------------------");
	deque.add("virat");
	System.out.println(deque);
	deque.pollFirst();
	System.out.println(deque);
	deque.pollLast();
	System.out.println(deque);
	System.out.println("---------------------------------------");
	deque.clear();
	System.out.println(deque);
	
	}

}
