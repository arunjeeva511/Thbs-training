package SessiononCollections;
import java.util.*;
public class HashSetExample {

	public static void main(String[] args) {
		ArrayList<Integer>number=new ArrayList<Integer>();
		number.add(3);
		number.add(4);
		number.add(40);
		HashSet<Integer>num=new HashSet(number);
		num.add(50);
		num.add(80);
		num.add(3);
		num.add(40);
		Iterator it=num.iterator();
		//while(it.hasNext()) {
			//System.out.println(it.next());
		//}
		for(Integer li:num) {
			System.out.println(li);
			
		}
	}

}
