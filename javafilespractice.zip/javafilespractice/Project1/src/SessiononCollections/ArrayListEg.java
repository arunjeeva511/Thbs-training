package SessiononCollections;
import java.util.*;
public class ArrayListEg {

	public static void main(String[] args) {
		ArrayList list=new ArrayList();
		list.add(60);
		list.add("arun");
		list.add(40);
		list.add(30);
		list.add("abd");
		for(int i=0;i<list.size();i++) {
			System.out.println(list.get(i));
		}
		
	}

}
