package SessiononCollections;
import java.util.*;
import java.util.PriorityQueue;

public class QueueExample {

	public static void main(String[] args) {
		PriorityQueue<String>pq=new PriorityQueue<String>();
		pq.add("Arun");
		pq.add("sachin");
		pq.add("hello");
		pq.add("simon");
		pq.add("barrer");
		
		//System.out.println(pq);
		Iterator it=pq.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println("---------");
		pq.remove();
		//pq.poll();
		Iterator it1=pq.iterator();
		while(it1.hasNext()) {
			System.out.println(it1.next());
		}
		
	}

}
