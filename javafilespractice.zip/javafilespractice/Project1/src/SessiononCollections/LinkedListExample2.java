package SessiononCollections;

import java.util.LinkedList;

public class LinkedListExample2 {

	public static void main(String[] args) {
		LinkedList<String>list=new LinkedList<String>();
		list.add("arun");
		list.add("virat");
		list.add("abd");
		System.out.println("from linked list1"+" "+list);
		LinkedList<String>list1=new LinkedList<String>();
		list1.add("gayle");
		list1.add("polard");
		list1.add("hello");
		System.out.println("from linked list2"+" "+list1);
		
		list.addAll(list1);
		System.out.println("from list1 to list"+list);
		LinkedList<String>list2=new LinkedList<String>();
		list2.add("smith");
		list2.add("maxwell");
		list2.add("finch");
		System.out.println("from linked list 3"+list2);
		list.addAll(1, list2);
		System.out.println("from list3 to list1 at position1"+" "+list);
		
		
	}

}
