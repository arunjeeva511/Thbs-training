package SessiononCollections;

import java.util.LinkedList;
import java.util.Scanner;

public class LinkedUsingStudent {
	private String name;
	private String address;
	private double gpa;
	static LinkedList<LinkedUsingStudent>student=new LinkedList<LinkedUsingStudent>();
	static Scanner scan=new Scanner(System.in);
	public LinkedUsingStudent(String name,String address,double gpa) {
		super();
		this.name=name;
		this.address=address;
		this.gpa=gpa;
	}
	public String getName() {
		return name;
	}
	public String getAddress() {
		return address;
	}
	public double getGpa() {
		return gpa;
	}

	public static void main(String[] args) {
		for(int i=0;i<=2;i++) {
			System.out.println("enter the name");
			String name=scan.next();
			System.out.println("enter the address");
			String address=scan.next();
			System.out.println("enter the gpa");
			double gpa=scan.nextDouble();
			student.add(new LinkedUsingStudent(name,address,gpa));
			}
		System.out.println(student);
	}
	public String toString() {
		return  "Student[name="+name+",address="+address+",gpa="+gpa+"]";
		
	}

}
