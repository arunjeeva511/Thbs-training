package SessionOnArrays;

import java.util.Scanner;

public class SinglDimensionArray {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the size of array");
		int n=sc.nextInt();
		int arr1[]=new int[n];
		for(int i=0;i<=arr1.length-1;i++) {
			System.out.println("enter the number"+i);
			arr1[i]=sc.nextInt();
		}
		for(int i=0;i<=arr1.length-1;i++) {
			System.out.println("the number are"+arr1[i]);
		}
		System.out.println(arr1.length);
		sc.close();

	}

}
