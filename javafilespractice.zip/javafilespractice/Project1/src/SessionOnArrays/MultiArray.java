package SessionOnArrays;

import java.util.Scanner;

public class MultiArray {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number of students");
		int stu=sc.nextInt();
		System.out.println("enter the number of subjects");
		int sub=sc.nextInt();
		int marks[][]=new int[stu][sub];
		for(int i=0;i<=marks.length-1;i++) {
			for(int j=0;j<=marks[i].length-1;j++) {
				System.out.println("enter the marks of student"+i+" "+"subject"+" "+j+" ");
				marks[i][j]=sc.nextInt();
			}
		
		}
		for(int i=0;i<=marks.length-1;i++) {
			for(int j=0;j<=marks[i].length-1;j++) {
				System.out.print(" " + marks[i][j]);
			}
			System.out.println(" ");
		}
		
		

	}

}
