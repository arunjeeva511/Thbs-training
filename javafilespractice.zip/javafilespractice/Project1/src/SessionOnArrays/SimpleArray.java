package SessionOnArrays;

public class SimpleArray {
	 public static void main(String[] args) {
		int arr1[]=new int[4];
		arr1[0]=10;
		arr1[1]=20;
		arr1[2]=30;
		arr1[3]=40;
		System.out.println(arr1[2]);
		System.out.println(arr1[3]);
	}

}
