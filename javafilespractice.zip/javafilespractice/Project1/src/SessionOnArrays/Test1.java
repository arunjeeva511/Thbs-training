package SessionOnArrays;

public class Test1 {

	public static void main(String[] args) {
		int arr1[]= {20,40,60,80,90};
		for(int my:arr1) {
			System.out.println(my);
		}
	}

}
