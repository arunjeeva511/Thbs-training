package com.example;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
public class CheckingAddition {
	@Before
	public void beforeTest() {
		System.out.println("exceuted before test");
	}
	@Test
	public void testAdd() {
		System.out.println("actual results");
		assertEquals(60,AddtionExample.add(30, 30) );
		//assertEquals(70,AddtionExample.add(50, 30) );
	}
		@After
		public void afterTest() {
			System.out.println("excecuted after test");
			
		}
		
		
	}


