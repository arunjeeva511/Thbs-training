package com.example;
class Addition{
	public static int add(int a,int b) {
		return a+b;
	}
}

public class AddtionExample extends Addition {

	public static void main(String[] args) {
		Addition obj=new Addition();
		System.out.println(obj.add(30, 30));
		
	}

}
