package com.assign;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class ValidatIonCheckingForUserAndPassword {
	
	@Test
public void check() {
		
		 
		//assertEquals("true", CheckingForUser.checkingValid("admin", "admin123"));
		//assertEquals("enter the fields", CheckingForUser.checkingValid(" "," "));
		//assertEquals("false", CheckingForUser.checkingValid("admin", "admin1"));
		//assertEquals("false", CheckingForUser.checkingValid("amin", "admin123"));
		//assertEquals("false", CheckingForUser.checkingValid("admi", "admin1"));
		}
}
