package com.assign;
class Subtraction{
	public static int sub(int a,int b) {
		return a-b;
	}
}
public class SubtractionExample  extends Subtraction{
	public static int mul(int a,int b) {
		return a*b;
	}
	public static void main(String[] args) {
		System.out.println(Subtraction.sub(50, 30));
		System.out.println(mul(2,4));
		

	}

}
