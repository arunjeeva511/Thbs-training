package com.assign;

public class Practice {

	public static void main(String args[]) {
		
	
	}
	}


