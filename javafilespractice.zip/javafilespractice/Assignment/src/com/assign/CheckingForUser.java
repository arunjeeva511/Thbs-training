package com.assign;

import java.util.Scanner;
class Validation{
	 public static String checkingValid(String username,String password) {
		 if(username.isEmpty() || password.isEmpty()) {
		
			 return "enter the fields";
		 }
		 else if(username=="admin"&& password=="admin123"){
			 return "true";
		 }
		 else {
			 return "false";
		 }
		 }
		 
		 
	 }


public class CheckingForUser extends Validation {
	public static void main(String[] args) {
		Validation valid=new Validation();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the username");
		String username=sc.nextLine();
		System.out.println("enter the password");
		String password=sc.nextLine();
		 String result=valid.checkingValid(username, password);
		System.out.println(result);
	}

}
