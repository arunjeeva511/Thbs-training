package com.assign;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class CheckingForSubtraction {
	@Test
 public void testSub() {
	 assertEquals(20,SubtractionExample.sub(30, 10));
	 assertEquals(10,SubtractionExample.mul(5, 2));
	 //assertEquals(40,SubtractionExample.sub(100, 70));
 }
}
