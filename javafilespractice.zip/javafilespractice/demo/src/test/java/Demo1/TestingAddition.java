package Demo1;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import Calculation.CalciTest;

public class TestingAddition {
	@Test
	public void testadd() {
		assertEquals(60,CalciTest .add(40, 20));
		
	}
}
