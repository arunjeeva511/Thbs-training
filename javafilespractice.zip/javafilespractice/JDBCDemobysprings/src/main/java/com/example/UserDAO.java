package com.example;

import org.springframework.jdbc.core.JdbcTemplate;

public class UserDAO {
	private JdbcTemplate jdbcTemplate;
	
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	public int saveUser(User user) {
		String query="insert into users values("+user.getId()+",'"+user.getEmail()+"','"+user.getPassword()+"')";
		return jdbcTemplate.update(query);
	}
	public int updateUser(User user) {
		String query = "update users set email='"+user.getEmail()+"', password= '"+user.getPassword()+"' where id="+user.getId()+"";
		return jdbcTemplate.update(query);
		
	}
	public int deleteUser(User user) {
		String query = "delete from users where id='"+user.getId()+"'";
		return jdbcTemplate.update(query);
	}
	

}
