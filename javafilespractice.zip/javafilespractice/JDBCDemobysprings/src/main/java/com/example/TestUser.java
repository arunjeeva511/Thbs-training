package com.example;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class TestUser {

	public static void main(String[] args) {
		ApplicationContext cx= new ClassPathXmlApplicationContext("applicationContext.xml");
		//Resource rs = new ClassPathResource("applicationContext.xml");
		//BeanFactory factory = new XmlBeanFactory(rs);
		UserDAO userdao = (UserDAO) cx.getBean("userDAO");
		int result = userdao.saveUser(new User(102,"pragathi@gmail.com","an@123"));
		//int result1 = userdao.saveUser(new User(102,"pragathi@gmail.com","pragun@123"));
		//int result=userdao.updateUser(new User(102,"pragu@gmail.com","arun@gmail.co"));
		//int result =userdao.deleteUser(new User(102,null,null));
		System.out.println(result);
	}

}
