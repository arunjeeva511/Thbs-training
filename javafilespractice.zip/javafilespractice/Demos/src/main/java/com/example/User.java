package com.example;

public class User {
	 private String username;
	  private String password;
	  public User() {
		  System.out.println("default construtor");
	  }
	  public User(String username,String password) {
		  this.username=username;
		  this.password=password;
	  }
	  void dispaly() {
		  System.out.println("username is:"+" "+username+", "+"password is:"+" "+password);
	  }
}
