package mysqlconnector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Writing {

	public static void main(String[] args) throws Exception {
		int age=45;
		String name="pragathi";
		String query="insert into students values('"+name+"',"+age+")";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sample_db","root","admin");
		Statement stmt=con.createStatement();
		int count=stmt.executeUpdate(query);
		System.out.println(count+"rows affected");
		stmt.close();
		con.close();
		
	}

}
