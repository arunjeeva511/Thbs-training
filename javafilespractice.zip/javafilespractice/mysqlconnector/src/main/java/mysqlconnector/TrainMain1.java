package mysqlconnector;

import java.sql.SQLException;
import java.util.Scanner;

public class TrainMain1 {

	public static void main(String[] args) throws SQLException {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the train number:");
		int number=sc.nextInt();
		Passenger1 p=new Passenger1();
	
		Ticket1 ticket=new Ticket1();
		Train1 train= ticket.checktrain(number);
		System.out.println(train.trainname);
		if(ticket.checktrain(number)!=null) {
			System.out.println("enter the name:");
			String name=sc.next();
			System.out.println("entre the age:");
			int age=sc.nextInt();
			System.out.println("enter the gender:");
			String gender=sc.next();
			p.name=name;
			p.age=age;
			p.gender=gender;
			ticket.addPassenger(p);
		}
	}

}
