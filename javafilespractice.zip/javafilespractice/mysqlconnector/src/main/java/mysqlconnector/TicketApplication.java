package mysqlconnector;


import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class TicketApplication {
	
	static Connection con= null;
	static Scanner sc = new Scanner(System.in);
	static ResultSet rs,set;	
	static PreparedStatement st = null;
	static Statement stmt  = null;
	static PrintWriter writer;
	static String pnr;
	static int passid;
	public static void main(String[] args) throws SQLException {
	Date today = new Date();
	DateFormat dd = new SimpleDateFormat("yyyymmdd");
	
	
	Ticket tkt;

	
	String fare="10";
	int trainnum,passengers,counter = 100;
	double price,totalprice = 0;
	
	try {
			con = DbCon.create("trains");		
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
	
		String fileName;
		
		String file = "C:\\Users\\user75\\Desktop\\TrainPassenger\\";
		
		System.out.println("Enter train number");
		trainnum = sc.nextInt();
		if(trainExist(trainnum)) {			
			System.out.println("Enter travel date 'dd/mm/yyyy'");
			Date userdate = new Date(sc.next());			
			if(userdate.compareTo(today) > 0) {				
				System.out.print("Enter number of passesngers : ");
				passengers = sc.nextInt();
				
				String [][]usr = new String[passengers][3];
				
				tkt = new Ticket(userdate, trainnum);
				
				for(int i=0;i<passengers;i++) {
					System.out.print("Enter passenger name : ");
					usr[i][0] = sc.next();
					System.out.print("enter age : ");
					usr[i][1] = sc.next();
					System.out.println("Enter Gender (M/F) : ");
					usr[i][2] = sc.next();
					Passenger p  = new Passenger();
					passid = p.insertPassdetails(usr[i][0],Integer.parseInt(usr[i][1]),usr[i][2].charAt(0));
				}			
				//Passengers p  = new Passengers(usr);
				String qry = "select * from trains where train_no ="+trainnum+";";
				try {
					st = con.prepareStatement(qry);
					rs = st.executeQuery(); 
					
					while(rs.next()) {
						try {
							String from = rs.getString(3);
							String to = rs.getString(4);
							price = rs.getDouble(5);
							fileName  = (""+from.charAt(0)+""+to.charAt(0)+"_"+dd.format(userdate)+"_"+counter++).toUpperCase();
							pnr=fileName;
							file = file+fileName;
							writer = new PrintWriter(file);
							writer.println("PNR\t\t : "+pnr);
							writer.println("Train no\t : "+rs.getInt(1));
							writer.println("train name\t : "+rs.getString(2));
							writer.println("From\t\t : "+from);
							writer.println("To\t\t : "+to);
							writer.println("Travel date\t : "+userdate+"\n");
							writer.println("\nPassengers : ");
							
							writer.println(String.format("%15s   %15s   %15s   %15s ","name","age","Gender","Fare"));
							for(int i=0;i<passengers;i++) {
								String name = usr[i][0];
								int age = Integer.parseInt(usr[i][1]);
								char gender  = usr[i][2].charAt(0);
								if(age <= 12)
									price = price * (0.5);
								else if(age >= 60)
									price = price * (0.6);
								else if(gender == 'f' || gender == 'F')
									price = price * (0.25);
								String detail = String.format("%15s   %15s   %15s   %15s ",name,age,gender,price);
								totalprice  += price; 
								writer.println(detail);
								
							}
							
							writer.println("\nTotal Price : "+totalprice);
							
							
							System.out.println("Ticket Booked with PNR : "+fileName);
							
							tkt.generateTicket();
							
						} catch (FileNotFoundException e) {
							e.printStackTrace();
						}
						finally {
							
						}
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}finally {
					writer.close();
					con.close();
					st.close();
					rs.close();					
				}
			}
		else 
			System.out.println("Travel date is before current date");		
		}	
		else
			System.out.println("Train with given train number is does not exist");
	}


	private static boolean trainExist(int trainnum) throws SQLException  {

		String q = "select * from trains where train_no = "+trainnum+"";
		boolean flag = false;
		try {
			stmt =  con.createStatement();
			set = stmt.executeQuery(q);
			if(set.next()) {
				flag = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			set.close();
		}
		
		
		return flag;
	}
	
	public static String getPNR() {
		return pnr;
	}
	public static int getpassid() {
		return passid;
	}
}


