package mysqlconnector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Ticket1 {
 public Train1 checktrain(int trainno) {
	 try {
	 	String query="select train_name from trains where train_no="+trainno;
	 	Train1 train= new Train1();
	 	train.trainno=trainno;
	 	Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/trains","root","admin");
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery(query);
		rs.next();
		String trainname=rs.getString(1);
		train.trainname=trainname;
		return train;
	 }
	 catch(Exception e)
	 {
		 e.printStackTrace();
	 }
	 return null;
	 }
 
 public void addPassenger(Passenger1 passenger) throws SQLException {
	 Scanner sc=new Scanner(System.in);
	 System.out.println("enter the number of passengers");
	 int number=sc.nextInt();
	 int i=1;
	 while(i<=number) {
 
	 String query="insert into trains values(?,?,?)";
	 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/trains","root","admin");
			PreparedStatement pst;
	try {
		pst=con.prepareStatement(query);
		pst.setString(2, passenger.name);
		pst.setInt(3, passenger.age);
		pst.setString(4, passenger.gender);
		int count=pst.executeUpdate();
		System.out.println("inserted sucessfully");
 }
	catch(Exception e) {
		e.printStackTrace();
	}

	i++; 
 }
	
 }
}
	 

