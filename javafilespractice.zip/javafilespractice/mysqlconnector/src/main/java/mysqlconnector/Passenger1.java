package mysqlconnector;

public class Passenger1 {
	String name;
	 int age;
	 String gender;
	}
