package mysqlconnector;

public class Train1 {
	 int trainno;
	 String trainname;
	String source;
	 String destination;
	 int ticketprice;
}