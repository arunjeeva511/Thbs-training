package mysqlconnector;
import java.util.*;
import java.sql.*;
public class TestConnection {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sample_db","root","admin");
			Statement stmt=con.createStatement();
			stmt.executeUpdate("insert into contacts values(8,'Arun','arun@gmail.com')");
			System.out.println("updated successfully............");
			//stmt.executeUpdate("delete from contacts where cid=7");
			ResultSet rs=stmt.executeQuery("select * from contacts");
			while(rs.next()) {
				System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3));
			}
			
		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}

	}

}
