package mysqlconnector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DynamicWriting {

	public static void main(String[] args) throws Exception {
		Scanner sc=new Scanner(System.in);
		while(true) {
		System.out.println("enter the age");
		int age=sc.nextInt();
		System.out.println("enter the name");
		String name=sc.next();
		String query="insert into students values(?,?)";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sample_db","root","admin");
		PreparedStatement st=con.prepareStatement(query);
		st.setString(1, name);
		st.setInt(2, age);
		int count=st.executeUpdate();
		System.out.println("update sucessfull"+count);
	System.out.println("do yo want to continue(y/n)");
	String option=sc.next();
	if(option.equalsIgnoreCase("No")) {
		break;
	}
		st.close();
		con.close();
		}

	}

}
