package mysqlconnector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UsingClassReadingvalues  {

	public static void main(String[] args)throws Exception {
		StudentDAO dao=new StudentDAO();
		Student s1=dao.getStudent(2);//2 is the age
		System.out.println(s1.name);

	}

}
class StudentDAO{
	public Student getStudent(int age) {
		try {
		String query="select name from students where age="+age;
		Student s=new Student();
		s.age=age;
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sample_db","root","admin");
		Statement stmt=con.createStatement();
		ResultSet rst=stmt.executeQuery(query);
		rst.next();
		String name=rst.getString(1);
		s.name=name;
		return s;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
}
class Student{
	String name;
	int age;
}