package mysqlconnector;




import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Ticket {
	private Date traveldate;
	private int  trains;
	private String pnr;
	int counter ;
	DateFormat df = new SimpleDateFormat("yyyy/mm/dd");
	Connection con ;
	
	public Ticket(Date traveldate, int train) {
		super();
		this.traveldate = traveldate;
		this.trains = train;
	}
	
	

	public Date getTraveldate() {
		return traveldate;
	}

	public void setTraveldate(Date traveldate) {
		this.traveldate = traveldate;
	}

	public int getTrains() {
		return trains;
	}

	public void setTrains(int trains) {
		this.trains = trains;
	}

	public String getPnr() {
		return pnr;
	}

	public void setPnr(String pnr) {
		this.pnr = pnr;
	}

	public int getCounter() {
		return counter;
	}
	
	
	public String generatePNR() {
		return null;
	}
	public double calcPassengerFare() {
		return 0;
	}
	public void addPassenger(String name,int age,char gender) throws SQLException {
		Passenger psn = new Passenger(name, age, gender);
		//System.out.println("passenger added...");
	}
	
	public double calculateTotalTicketPrice(){
		return 0.0;
	}
	public StringBuffer generateTicket() {
		 try {
				 con = DbCon.create("trains");
				String q = "INSERT INTO ticket (pnr,traveldate,pass_id,train_no)VALUES('"+TicketApplication.getPNR()+"','"+df.format(traveldate)+"',"+TicketApplication.getpassid()+","+trains+");";
				//System.out.println(q);
				Statement st = con.createStatement();
				int update = st.executeUpdate(q);
				//System.out.println(update+"'s rows changerd 0.001s");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				if(con != null)
					try {
						con.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
		}
		 
		
		return null;
	}
	public void writeTicket() {
		
	}
	
}


