package mysqlconnector;

import java.util.*;
import java.sql.*;

public class Reading {
	public static void main(String[] args) throws Exception {
		String query="select * from students";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sample_db","root","admin");
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery(query);
		while(rs.next()) {
			System.out.println(rs.getString(1)+" "+rs.getInt(2));
		}

		
	}

}
