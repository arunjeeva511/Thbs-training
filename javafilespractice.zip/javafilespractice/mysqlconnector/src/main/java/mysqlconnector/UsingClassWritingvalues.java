package mysqlconnector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UsingClassWritingvalues {

	public static void main(String[] args)  throws Exception {
		StudentDAO1 dao=new StudentDAO1();
		Student1 s2=new Student1();
		s2.name="archana";
		s2.age=23;
		dao.addStudent(s2);

	}
}
	class StudentDAO1 {
		Connection con=null;
		public void addStudent(Student1 s) throws Exception {
			String query = "insert into students values(?,?)";
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sample_db","root","admin");
			PreparedStatement pst;
		try {
			pst=con.prepareStatement(query);
			pst.setString(1, s.name);
			pst.setInt(2, s.age);
			int rs=pst.executeUpdate();
			System.out.println("update successfull"+rs);
		}
		catch(Exception e) {
			
		}
		}
		
	}
	class Student1{
		int age;
		String name;
	

}
