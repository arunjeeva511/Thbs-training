package com.trains;

public class Trains {
	private int trainno;
	private String trainname;
	private String trainsource;
	private String traindestination;
	private int trainticketprice;
	public int getTrainno() {
		return trainno;
	}
	public void setTrainno(int trainno) {
		this.trainno = trainno;
	}
	public String getTrainname() {
		return trainname;
	}
	public void setTrainname(String trainname) {
		this.trainname = trainname;
	}
	public String getTrainsource() {
		return trainsource;
	}
	public void setTrainsource(String trainsource) {
		this.trainsource = trainsource;
	}
	public String getTraindestination() {
		return traindestination;
	}
	public void setTraindestination(String traindestination) {
		this.traindestination = traindestination;
	}
	public int getTrainticketprice() {
		return trainticketprice;
	}
	public void setTrainticketprice(int trainticketprice) {
		this.trainticketprice = trainticketprice;
	}
	public void display() {
		System.out.println("Train no:"+" "+trainno+", train name:"+" "+ trainname+" , train source:"+" "+trainsource+" ,train Destination :"+" "+traindestination+" ,ticket price: "+" "+trainticketprice);
	}
	
}
