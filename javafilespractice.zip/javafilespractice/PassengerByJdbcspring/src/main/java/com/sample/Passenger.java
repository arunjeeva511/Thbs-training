package com.sample;

public class Passenger {
	private String passname;
	private int passage;
	private String passgender;
	private int passid;
	public Passenger(int passid, String passname, int passage,String passgender) {
		super();
		this.passname = passname;
		this.passage = passage;
		this.passgender = passgender;
		this.passid=passid;
		
	}
	public String getPassname() {
		return passname;
	}
	public void setPassname(String passname) {
		this.passname = passname;
	}
	public int getPassage() {
		return passage;
	}
	public void setPassage(int passage) {
		this.passage = passage;
	}
	public String getPassgender() {
		return passgender;
	}
	public void setPassgender(String passgender) {
		this.passgender = passgender;
	}
	public int getPassid() {
		return passid;
	}
	public void setPassid(int passid) {
		this.passid = passid;
	}
	

}
