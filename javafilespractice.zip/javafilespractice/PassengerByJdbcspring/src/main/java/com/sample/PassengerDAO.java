package com.sample;

import org.springframework.jdbc.core.JdbcTemplate;

public class PassengerDAO {
	private JdbcTemplate jdbctemp;

	public JdbcTemplate getJdbctemp() {
		return jdbctemp;
	}

	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}
	public int savePassenger(Passenger passenger) {
		String query="insert into passengers values("+passenger.getPassid()+",'"+passenger.getPassname()+"',"+passenger.getPassage()+",'"+passenger.getPassgender()+"')";
		return jdbctemp.update(query);
	}
	public int updatePassenger(Passenger passenger) {
		String query = "update passengers set passname='"+passenger.getPassname()+"',passage="+passenger.getPassage()+", passgender= '"+passenger.getPassgender()+"' where passid="+passenger.getPassid()+"";
		return jdbctemp.update(query);
	}
	public int deletePassenger(Passenger passenger) {
		String query = "delete from passengers where passid="+passenger.getPassid();
		return jdbctemp.update(query);
	}

}
