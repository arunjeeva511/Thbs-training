package com.sample;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class TestPassenger {

	public static void main(String[] args) {
		Resource rs = new ClassPathResource("PassengerContext.xml");
		BeanFactory factory = new XmlBeanFactory(rs);
				PassengerDAO passdao = (PassengerDAO) factory.getBean("passDAO");
				//int result = passdao.savePassenger(new Passenger(101,"Arun",22,"male"));
				//int result = passdao.savePassenger(new Passenger(102,"Pragathi",23,"female"));
				//int result1 = passdao.savePassenger(new Passenger(103,"virat",32,"male"));
				//int result=passdao.updatePassenger(new Passenger(103,"virat",29,"male"));
				int result=passdao.deletePassenger(new Passenger(103,"virat",29,"male"));
				System.out.println(result);

	}

}
