package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="trains")
public class Train {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="trainno")
	private int trainno;
	@Column(name="trainname")
	private String trainname;
	@Column(name="source")
	private String source;
	@Column(name="destination")
	private String destination;
	@Column(name="ticketprice")
	private  int ticketprice;
	Train(){
		
	}
	public Train(String trainname, String source, String destination, int ticketprice) {
		super();
		this.trainname = trainname;
		this.source = source;
		this.destination = destination;
		this.ticketprice = ticketprice;
	}
	public int getTrainno() {
		return trainno;
	}
	public void setTrainno(int trainno) {
		this.trainno = trainno;
	}
	public String getTrainname() {
		return trainname;
	}
	public void setTrainname(String trainname) {
		this.trainname = trainname;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getTicketprice() {
		return ticketprice;
	}
	public void setTicketprice(int ticketprice) {
		this.ticketprice = ticketprice;
	}
	
	
	

}
