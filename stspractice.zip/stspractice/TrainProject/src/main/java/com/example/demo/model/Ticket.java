package com.example.demo.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tickets")
public class Ticket {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="counter")
	private int counter;
	@Column(name="pnr")
	private String pnr;
	@Column(name="traveldate")
	private Date traveldate;
	@Column(name="no_of_pass")
	private int no_of_pass;
	@Column(name="train_name")
	private String train_name;
	@Column(name="total_fare")
	private int total_fare;
	
	Ticket(){
		
	}

	public Ticket(String pnr, Date traveldate, int no_of_pass, String train_name, int total_fare) {
		super();
		this.pnr = pnr;
		this.traveldate = traveldate;
		this.no_of_pass = no_of_pass;
		this.train_name = train_name;
		this.total_fare = total_fare;
	}

	public int getCounter() {
		return counter;
	}

	public void setCounter(int counter) {
		this.counter = counter;
	}

	public String getPnr() {
		return pnr;
	}

	public void setPnr(String pnr) {
		this.pnr = pnr;
	}

	public Date getTraveldate() {
		return traveldate;
	}

	public void setTraveldate(Date traveldate) {
		this.traveldate = traveldate;
	}

	public int getNo_of_pass() {
		return no_of_pass;
	}

	public void setNo_of_pass(int no_of_pass) {
		this.no_of_pass = no_of_pass;
	}

	public String getTrain_name() {
		return train_name;
	}

	public void setTrain_name(String train_name) {
		this.train_name = train_name;
	}

	public int getTotal_fare() {
		return total_fare;
	}

	public void setTotal_fare(int  total_fare) {
		this.total_fare = total_fare;
	}

	@Override
	public String toString() {
		return "Ticket [counter=" + counter + ", pnr=" + pnr + ", traveldate=" + traveldate + ", no_of_pass="
				+ no_of_pass + ", train_name=" + train_name + ", total_fare=" + total_fare + "]";
	}
	

	

	

	}
