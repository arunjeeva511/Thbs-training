package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="passengers")
public class Passenger {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="passid")
	private int passid;
	@Column(name="passengername")
	private String passengername;
	@Column(name="passengerage")
	private int passengerage;
	@Column(name="passengergender")
	private String passengergender;
	
	Passenger(){
		
	}

	public Passenger(String passengername, int passengerage, String passengergender) {
		super();
		this.passengername = passengername;
		this.passengerage = passengerage;
		this.passengergender = passengergender;
	}

	public int getPassid() {
		return passid;
	}

	public void setPassid(int passid) {
		this.passid = passid;
	}

	public String getPassengername() {
		return passengername;
	}

	public void setPassengername(String passengername) {
		this.passengername = passengername;
	}

	public int getPassengerage() {
		return passengerage;
	}

	public void setPassengerage(int passengerage) {
		this.passengerage = passengerage;
	}

	public String getPassengergender() {
		return passengergender;
	}

	public void setPassengergender(String passengergender) {
		this.passengergender = passengergender;
	}

	@Override
	public String toString() {
		return "Passenger [passid=" + passid + ", passengername=" + passengername + ", passengerage=" + passengerage
				+ ", passengergender=" + passengergender + "]";
	}

		
	
	

}
