package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Ticket;
import com.example.demo.repository.TicketRepository;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api")

public class TicketController {
	@Autowired
	TicketRepository ticketRepository;
	@PostMapping("/tickets")
	public ResponseEntity<Ticket> createTicket(@RequestBody Ticket ticket){
		try {
			Ticket _ticket= ticketRepository.save(new Ticket(ticket.getPnr(),ticket.getTraveldate(),ticket.getNo_of_pass(),ticket.getTrain_name(),ticket.getTotal_fare()));
			return new ResponseEntity<>(_ticket,HttpStatus.CREATED);
              }
		catch(Exception ex) {
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/tickets")
	public ResponseEntity<List<Ticket>> getAllPassengers(){
		try {
			List<Ticket> tickets =new ArrayList<Ticket>();
			ticketRepository.findAll().forEach(tickets::add);
			return new ResponseEntity<>(tickets,HttpStatus.OK);
			
		}
		catch(Exception ex) {
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@GetMapping("/tickets/{counter}")
	public ResponseEntity<Ticket> getPassengerById(@PathVariable("counter") int counter){
		Optional<Ticket> ticketData =ticketRepository.findById(counter);
		if(ticketData.isPresent()) {
			return new ResponseEntity<>(ticketData.get(),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		
	}
	@PutMapping("/tickets/{counter}")
	public ResponseEntity<Ticket> updatePassenger(@PathVariable("counter") int counter,@RequestBody Ticket ticket){
		Optional<Ticket> ticketData=ticketRepository.findById(counter);
		if(ticketData.isPresent()) {
			Ticket _ticket=ticketData.get();
			_ticket.setPnr(ticket.getPnr());
			_ticket.setTraveldate(ticket.getTraveldate());
			_ticket.setNo_of_pass(ticket.getNo_of_pass());
			_ticket.setTrain_name(ticket.getTrain_name());
			_ticket.setTotal_fare(ticket.getTotal_fare());
			return new ResponseEntity<>(ticketRepository.save(_ticket),HttpStatus.OK);
			
		}
		else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		
	}
	@DeleteMapping("/tickets/{counter}")
	public ResponseEntity<HttpStatus> deleteUser(@PathVariable("counter") int counter){
		try {
			ticketRepository.deleteById(counter);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		catch(Exception ex) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	

}
