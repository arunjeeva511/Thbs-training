package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Passenger;
import com.example.demo.repository.PassengerRepository;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api")
public class PassengerController {
	@Autowired
	PassengerRepository passengerRepository;
	@PostMapping("/passengers")
	public ResponseEntity<Passenger> createPassenger(@RequestBody Passenger passenger){
		try {
			Passenger _passenger= passengerRepository.save(new Passenger(passenger.getPassengername(),passenger.getPassengerage(),passenger.getPassengergender()));
			return new ResponseEntity<>(_passenger,HttpStatus.CREATED);
              }
		catch(Exception ex) {
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/passengers")
	public ResponseEntity<List<Passenger>> getAllPassengers(){
		try {
			List<Passenger> passengers =new ArrayList<Passenger>();
			passengerRepository.findAll().forEach(passengers::add);
			return new ResponseEntity<>(passengers,HttpStatus.OK);
			
		}
		catch(Exception ex) {
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@GetMapping("/passengers/{passid}")
	public ResponseEntity<Passenger> getPassengerById(@PathVariable("passid") int passid){
		Optional<Passenger> passengerData =passengerRepository.findById(passid);
		if(passengerData.isPresent()) {
			return new ResponseEntity<>(passengerData.get(),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		
	}
	@PutMapping("/passengers/{passid}")
	public ResponseEntity<Passenger> updatePassenger(@PathVariable("passid") int passid,@RequestBody Passenger passenger){
		Optional<Passenger> passengerData=passengerRepository.findById(passid);
		if(passengerData.isPresent()) {
			Passenger _passenger=passengerData.get();
			_passenger.setPassengername(passenger.getPassengername());
			_passenger.setPassengerage(passenger.getPassengerage());
			_passenger.setPassengergender(passenger.getPassengergender());
			return new ResponseEntity<>(passengerRepository.save(_passenger),HttpStatus.OK);
			
		}
		else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		
	}
	@DeleteMapping("passengers/{passid}")
	public ResponseEntity<HttpStatus> deleteUser(@PathVariable("passid") int passid){
		try {
			passengerRepository.deleteById(passid);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		catch(Exception ex) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	

}
